package com.naldoskie.app;
import android.app.*;
import android.view.*;
import android.os.*;
import android.webkit.*;

import androidx.annotation.RequiresApi;

public class RateFragment extends Fragment
{
	private WebView webView;
	@RequiresApi(api = Build.VERSION_CODES.M)
    @Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
	{
		// TODO: Implement this method
		View v = inflater.inflate(R.layout.rate_frag,container,false);
		webView = (WebView) v.findViewById(R.id.webView);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.loadUrl("market://details?id="+getContext().getPackageName());
        webView.setWebViewClient(new MyWebViewClient());
        webView.setHorizontalScrollBarEnabled(false);
        webView.requestFocus();
		return v;	
	}
private class MyWebViewClient extends WebViewClient {
     
	@Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            view.loadUrl(url);
            return true;
        }
    }
	
}
