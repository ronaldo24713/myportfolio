package com.naldoskie.app;
import android.app.*;
import android.os.*;
import android.view.*;

public class SettingFragment extends Fragment
{

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
	{
		// TODO: Implement this method
		View view = inflater.inflate(R.layout.settings_layout,container,false);
		return view ;
	}

	

	
}
