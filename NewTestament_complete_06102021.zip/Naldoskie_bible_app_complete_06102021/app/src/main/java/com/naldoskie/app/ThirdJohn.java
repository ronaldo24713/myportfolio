package com.naldoskie.app;

import android.app.*;
import android.content.*;
import android.os.*;
import android.view.*;
import android.widget.*;

public class ThirdJohn extends  Activity {
public static ListView listView2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.book_chapter_layout);

        final String[] third_john_chapters = getResources().getStringArray(R.array.third_john_chapter);
        final  String[] content = getResources().getStringArray(R.array.third_john_content);

        listView2 = (ListView) findViewById(R.id.list2);
        ArrayAdapter<String> myAdapter = new ArrayAdapter<String>(ThirdJohn.this,R.layout.entry,R.id.txtView1,third_john_chapters);
        listView2.setAdapter(myAdapter);

        listView2.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String third_john_chapters_content = content[position];

                Intent intent = new Intent(getApplicationContext(), BookChaptersContent.class);
                intent.putExtra("Articles",third_john_chapters_content);
                startActivity(intent);

            }
        });

    }
}
