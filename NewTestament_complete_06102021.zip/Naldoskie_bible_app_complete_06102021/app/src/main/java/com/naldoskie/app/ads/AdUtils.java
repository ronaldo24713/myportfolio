package com.naldoskie.app.ads;

import com.google.android.gms.ads.AdRequest;

import com.google.android.gms.ads.AdRequest;

public class AdUtils {
    private  static final String ADS_TEST_DEVICE ="F624C2FB22C02758CBA3A5216F5325FA";

    public static AdRequest adBuilder(){
        //noinspection deprecation
    return  new AdRequest.Builder().build();

   }
    private  AdUtils(){}
}
