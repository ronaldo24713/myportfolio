package com.naldoskie.app;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.app.DialogFragment;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.WindowManager;
import android.widget.SearchView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;
import com.google.android.gms.ads.MobileAds;
import com.naldoskie.app.ads.AdUnitID;
import com.naldoskie.app.ads.AdUtils;
import com.naldoskie.app.ads.AdsController;


public class BookChaptersContent extends AppCompatActivity implements AdsController
{
	    private InterstitialAd interstitialAd;
	    private AdView mAdView;
	
	@RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
	protected void onCreate(Bundle savedInstanceState)  
	{
		// TODO: Implement this method
		super.onCreate(savedInstanceState);
		setContentView(R.layout.books_content_layout);
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
		TextView textView =(TextView)findViewById(R.id.txtView2);
		Toolbar myToolbar = findViewById(R.id.custom_toolbar1);
		setSupportActionBar(myToolbar);
		String Chapter_content = getIntent().getStringExtra("Articles");
       textView.setText(Chapter_content);
		MyDialogFragment f = new MyDialogFragment();
		f.setCancelable(false);
		f.show(getFragmentManager(), "mydialog");
		initAds();
        showInterstitialAds();
        mAdView = (AdView) findViewById(R.id.ad_view1);
        MobileAds.initialize(this, "ca-app-pub-3046759544394124~7013549961");
        AdRequest adRequest = new AdRequest.Builder().build();
        mAdView.loadAd(adRequest);
	}
	
	@Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
//        Inflate main_menu.xml
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.option_menu, menu);
		
//		MenuItem menuItem = menu.findItem(R.id.searchItem);
//		SearchView searchView =(SearchView)menuItem.getActionView();
//		searchView.setQueryHint("Search here");
//		searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener(){
//
//				@Override
//				public boolean onQueryTextSubmit(String txtSubmit)
//				{
//					// TODO: Implement this method
//
//
//					return true;
//				}
//
//				@Override
//				public boolean onQueryTextChange(String newTxt)
//				{
//					// TODO: Implement this method
//					return true;
//				}
//			} 
//		);
        return true;
    }

    private void onAboutClick(){
        Uri uri = Uri.parse("https://www.ifindsolutionorg.blogspot.com");
        Intent intent = new Intent(Intent.ACTION_VIEW,uri);
        startActivity(intent);

    }

    private void RatingFeedBack(){
        Uri uri = Uri.parse( "market://details?id="+getApplicationContext().getPackageName());
        Intent intent = new Intent(Intent.ACTION_VIEW,uri);
        startActivity(intent);
    }
    private void onContactClick(){
        Uri uri = Uri.parse("https:www.naldoskie.xyz/p/contact-us.html");
        Intent intent = new Intent(Intent.ACTION_VIEW,uri);
        startActivity(intent);

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        switch (item.getItemId())
        {
			case R.id.searchItem:
				SearchView searchView = (SearchView)item.getActionView();
				searchView.setQueryHint("Search here");
				searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener(){

						@Override
						public boolean onQueryTextSubmit(String txtSubmit)
						{
							// TODO: Implement this method
						return true;
						}

						@Override
						public boolean onQueryTextChange(String newTxt)
						{
							// TODO: Implement this method

							return true;
						}
					} 
				);
				//Toast.makeText(this,"searching...",Toast.LENGTH_SHORT).show();
				break;
				
            case R.id.mainMenu_about:
                Toast.makeText(this, "develop by Ronaldo Ninal",Toast.LENGTH_SHORT).show();
                onAboutClick();
                break;
            case R.id.mainContactUs:
              //  Toast.makeText(this, "Visit: https://www.ifindsolutionorg.blogspot.com/contact-us.html",Toast.LENGTH_SHORT).show();
				onContactClick();
                break;
				
			case R.id.undoItem:
				Toast.makeText(this,"Undo",Toast.LENGTH_SHORT).show();
				onBackPressed();
				break;

            case R.id.ratingItem:
                Toast.makeText(this,"Rate my app",Toast.LENGTH_LONG).show();
                RatingFeedBack();
				break;

            case  R.id.mainMenuExit:
                finish();
                break;
				
			
			case R.id.saveItem:
				Toast.makeText(this,"saving",Toast.LENGTH_SHORT).show();
				onSaveInstanceState(new Bundle());
				break;
				
            case R.id.InterstitialAdsItem:
                showInterstitialAds();
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void showBannerAds() {

    }

    @Override
    public void showInterstitialAds() {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                showInsterstialAdInternal();
            }
        });

    }
    private void loadInterstitialAds(){
        if (isNetWorkConnected()){
            interstitialAd.loadAd(AdUtils.adBuilder());
        }
    }

    private void showInsterstialAdInternal(){
        if (interstitialAd.isLoaded()){
            interstitialAd.show();
        }
    }


    private void initAds() {


        interstitialAd = new InterstitialAd(this);
        interstitialAd.setAdUnitId(AdUnitID.INTERSTITIAL_ADS);
        interstitialAd.setAdListener(new AdListener(){

            @Override
            public void onAdClosed() {
                loadInterstitialAds();
            }
        });
        loadInterstitialAds();
    }


    @Override
    public boolean isNetWorkConnected() {
        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();
        return  networkInfo != null && networkInfo.isConnected();
    }
	
	@SuppressLint("ValidFragment")
    class MyDialogFragment extends DialogFragment
	{
		@RequiresApi(api = Build.VERSION_CODES.M)
        @Override
		public Dialog onCreateDialog(Bundle savedInstanceState) 
		{
			AlertDialog.Builder builder = new AlertDialog.Builder(getContext());

			builder.setTitle("Your feedback help us");
			builder.setMessage(" Rate this App now?");
			builder.setPositiveButton("Ok", new DialogInterface.OnClickListener() {

					@RequiresApi(api = Build.VERSION_CODES.M)
                    @Override
					public void onClick(DialogInterface p1, int p2)
					{
						// TODO: Implement this method
						startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse("market://details?id="+getContext().getPackageName())));

					}
				});

			builder.setNegativeButton("Maybe Later", new DialogInterface.OnClickListener(){

					@Override
					public void onClick(DialogInterface p1, int p2)
					{
						// TODO: Implement this method
					}	
				});

			return builder.create();
		}
	}	
}
