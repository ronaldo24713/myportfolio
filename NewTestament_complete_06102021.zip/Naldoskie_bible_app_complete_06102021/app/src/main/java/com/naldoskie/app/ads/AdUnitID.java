package com.naldoskie.app.ads;

public class AdUnitID {
//    public static final String BANNER_ADS = "ca-app-pub-3940256099942544/6300978111";
    public static final String  INTERSTITIAL_ADS = "ca-app-pub-3046759544394124/2098961179";
    private AdUnitID(){}
}
