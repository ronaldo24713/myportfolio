package com.naldoskie.app;
import android.content.*;
import android.os.*;
import android.support.v7.app.*;
import android.view.*;
import android.view.animation.*;
import android.widget.*;
import com.naldoskie.app.*;

public class SplashActivity extends AppCompatActivity
{
	private static int TIME_INTERVAL = 5000;
	Animation rightAnim,leftAnim;
	ImageView img;
	TextView txt;

	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		// TODO: Implement this method
		super.onCreate(savedInstanceState);
		setContentView(R.layout.splash_activity);
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
		
		rightAnim = AnimationUtils.loadAnimation(this,R.anim.right_to_left_anim);
		leftAnim = AnimationUtils.loadAnimation(this,R.anim.left_to_right_anim);
		
		img = (ImageView)findViewById(R.id.splashactivityImageView1);
		txt =(TextView)findViewById(R.id.splashactivityTextView1);
		
		img.setAnimation(leftAnim);
		txt.setAnimation(rightAnim);
		
		new Handler().postDelayed(new Runnable()
		{

				@Override
				public void run()
				{
					// TODO: Implement this method
					Intent intent = new Intent(getApplicationContext(),MainActivity.class);
					startActivity(intent);
					finish();
				}},TIME_INTERVAL);
		
		}
}
