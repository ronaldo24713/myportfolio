package com.naldoskie.app.ads;

public interface AdsController {

     void showBannerAds();
    void showInterstitialAds();
    boolean isNetWorkConnected();
}
