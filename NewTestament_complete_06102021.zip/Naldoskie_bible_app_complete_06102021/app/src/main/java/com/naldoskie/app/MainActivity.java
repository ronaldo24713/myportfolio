package com.naldoskie.app;
import android.app.*;
import android.os.*;
import android.support.design.widget.*;
import android.view.View;
import android.view.WindowManager;
import android.widget.AdapterView.*;

import androidx.annotation.RequiresApi;
import androidx.core.widget.*;
import android.content.Intent;
import android.content.*;

import android.widget.ListView;
import android.widget.ListAdapter;
import android.widget.AdapterView;
import android.widget.Toast;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import android.widget.ImageView;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.SearchView;
import android.widget.*;
import android.view.*;
import com.naldoskie.app.ads.*;
import android.net.*;
import java.util.*;
import com.google.android.gms.ads.*;

public class MainActivity extends AppCompatActivity implements OnItemClickListener,View.OnClickListener,AdsController
{

	private InterstitialAd interstitialAd;
	
	NavigationView nv;
	//ArrayAdapter<String> adapter;
	private ListAdapter listadapter;
	private FragmentManager fm;
	private FragmentTransaction ft;
	ListView lv;
	String[] txt= {"Home","About","Privacy","Rate app","Help"};
	
	
  @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
  @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
		nv = (NavigationView)findViewById(R.id.nav_view);
		View v= getLayoutInflater().inflate(R.layout.nav_item,null);
		nv.addView(v);
	  	initAds();
		showInterstitialAds();
		lv =(ListView)findViewById(R.id.listView);
	
		 listadapter = new MyAdapter(this,txt);
		lv.setAdapter(listadapter);
		lv.setOnItemClickListener(this);	
		Toolbar myToolbar = (Toolbar)findViewById(R.id.custom_toolbar1);
		myToolbar.collapseActionView();
		setSupportActionBar(myToolbar);
		
	  
	//  MyDialogFragment f = new MyDialogFragment();
	 // f.show(getFragmentManager(), "mydialog");
}
	
	
		
	@Override
	public void onItemClick(AdapterView<?> p1, View p2, int item, long p4)
	{
		 fm = getFragmentManager();
		ft = fm.beginTransaction();

		if(item==0){

			Intent intent = new Intent(getApplicationContext(),MainActivity.class);
			startActivity(intent);
			Toast.makeText(this,""+txt[item],Toast.LENGTH_SHORT).show();

			}

		else if(item==1){

		ft.replace(R.id.mainLinearLayout,new AboutActivity());
		ft.commit();
		Toast.makeText(this,""+txt[item],Toast.LENGTH_SHORT).show();
		}
		else if(item==2){
			ft.replace(R.id.mainLinearLayout, new PrivacyFragment());
			ft.commit();
			
			Toast.makeText(this,""+txt[item],Toast.LENGTH_SHORT).show();
		}
		else if(item==3){
			ft.replace(R.id.mainLinearLayout,new RateFragment());
			
			ft.commit();
			Toast.makeText(this,""+txt[item],Toast.LENGTH_SHORT).show();
		}
//		else if(item==4){
//			ft.replace(R.id.mainLinearLayout,new SettingFragment());
//			ft.commit();
//			Toast.makeText(this,""+txt[item],Toast.LENGTH_SHORT).show();
//
//		}
		else if(item==4){
			ft.replace(R.id.mainLinearLayout,new HelpFragment());
			ft.commit();
			
			Toast.makeText(this,""+txt[item],Toast.LENGTH_SHORT).show();
			
		}

		DrawerLayout dl=(DrawerLayout)findViewById(R.id.drawer_layout);
		dl.closeDrawers();
	
		
		}
		
		class MyAdapter extends ArrayAdapter<String>
			{
				MyAdapter(Context context, String[] data)	{
						super(context,R.layout.nav_entry,data);
					}

				@Override
				public View getView(int item, View view, ViewGroup parent)
					{
						// TODO: Implement this method
						LayoutInflater inflater = LayoutInflater.from(getApplicationContext());
					 view = inflater.inflate(R.layout.nav_entry,parent,false);

						String text = getItem(item);
						TextView txtView =(TextView)view.findViewById(R.id.entryTextView);
						txtView.setText(text);

						ImageView icon = (ImageView)view.findViewById(R.id.entryImageView);
						icon.setImageResource(android.R.drawable.ic_menu_info_details);
						if("Home".equals(text))
							icon.setImageResource(R.drawable.home);

						else if("About".equals(text))
							icon.setImageResource(R.drawable.ic_menu_info_details);


						else if("Privacy".equals(text))
							icon.setImageResource(R.drawable.privacy_policy);

						else if("Rate app".equals(text))
							icon.setImageResource(R.drawable.rating);

//						else if("Settings".equals(text))
//							icon.setImageResource(R.drawable.settings);

						else if("Help".equals(text))
							icon.setImageResource(R.drawable.help);
						return view;
						}

			}

		@Override
		public boolean onCreateOptionsMenu(Menu menu)
			{
				// TODO: Implement this method
				MenuInflater inflater= getMenuInflater();
				inflater.inflate(R.menu.option_menu,menu);
				//inflater.inflate(R.menu.edit_menu,menu);
				//MenuItem menuItem = menu.findItem(R.id.searchItem);
				
				return true;
			}

		@Override
		public boolean onOptionsItemSelected(MenuItem item)
			{
				// TODO: Implement this method
				switch(item.getItemId()){
					case R.id.undoItem:
						Toast.makeText(this,"Undo",Toast.LENGTH_SHORT).show();
						onBackPressed();
						break;
					
					case R.id.saveItem:
					Toast.makeText(this,"saving",Toast.LENGTH_SHORT).show();
					onSaveInstanceState(new Bundle());
					break;
						
//					case R.id.editItem:
//					Toast.makeText(this,"Edit",Toast.LENGTH_SHORT).show();
//					return true;
					
					case R.id.searchItem:
						SearchView searchView = (SearchView)item.getActionView();
						searchView.setQueryHint("Search here");
						searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener(){

								@Override
								public boolean onQueryTextSubmit(String txtSubmit)
								{
									// TODO: Implement this method


									return true;
								}

								@Override
								public boolean onQueryTextChange(String newTxt)
								{
									// TODO: Implement this method

									return true;
								}
							} 
						);
						
						//Toast.makeText(this,"searching...",Toast.LENGTH_SHORT).show();
						break;
						
					case R.id.mainMenu_about:
						Toast.makeText(this, "develop by Ronaldo Ninal",Toast.LENGTH_SHORT).show();
						onAboutClick();
						break;
					case R.id.mainContactUs:
						//  Toast.makeText(this, "Visit: https://www.ifindsolutionorg.blogspot.com/contact-us.html",Toast.LENGTH_SHORT).show();
						onContactClick();
						break;

					case R.id.ratingItem:
						Toast.makeText(this,"Rate my app",Toast.LENGTH_LONG).show();
						RatingFeedBack();
						break;

					case  R.id.mainMenuExit:
						finish();
						break;
					case R.id.InterstitialAdsItem:
              	 showInterstitialAds();
					break;
					
				}
				return super.onOptionsItemSelected(item);
			}	
		
	@Override
	public void onClick(View v)
	{
		// TODO: Implement this method
		int id = v.getId();
        switch (id){
				//== NEW TESTAMENT==
            case R.id.btn_1:
                Button b1 = (Button) v.findViewById(R.id.btn_1);
                Intent intent = new Intent(getApplicationContext(), MathewChapters.class);
				 startActivity(intent);
                break;

            case R.id.btn_2:
                Button b2 = (Button) v.findViewById(R.id.btn_2);
                Intent intent2 = new Intent(getApplicationContext(), MarkChapters.class);
                startActivity(intent2);
                break;
            case R.id.btn_3:
                Button b3 = (Button) v.findViewById(R.id.btn_3);
                Intent intent3 = new Intent(getApplicationContext(), LukeChapters.class);
                startActivity(intent3);
                break;

            case R.id.btn_4:
                Button b4 = (Button) v.findViewById(R.id.btn_4);
                Intent intent4 = new Intent(getApplicationContext(), JohnChapters.class);
                startActivity(intent4);
                break;
            case R.id.btn_5:
                Button b5 = (Button) v.findViewById(R.id.btn_5);
                Intent intent5 = new Intent(getApplicationContext(), ActsChapters.class);
                startActivity(intent5);
                break;
            case R.id.btn_6:
                Button b6 = (Button) v.findViewById(R.id.btn_6);
                Intent intent6 = new Intent(getApplicationContext(), RomansChapters.class);
                startActivity(intent6);
                break;
            case R.id.btn_7:
                Button b7 = (Button) v.findViewById(R.id.btn_7);
                Intent intent7 = new Intent(getApplicationContext(), Frst_CorrenthiansChapter.class);
                startActivity(intent7);
                break;
            case R.id.btn_8:
                Button b8 = (Button) v.findViewById(R.id.btn_8);
                Intent intent8 = new Intent(getApplicationContext(), Second_CorrenthiansChapter.class);
                startActivity(intent8);
                break;
            case R.id.btn_9:
                Button b9 = (Button) v.findViewById(R.id.btn_9);
                Intent intent9 = new Intent(getApplicationContext(), Galatians.class);
                startActivity(intent9);
                break;
            case R.id.btn_10:
                Button b10 = (Button) v.findViewById(R.id.btn_10);
                Intent intent10 = new Intent(getApplicationContext(), Ephesians.class);
                startActivity(intent10);
                break;
            case R.id.btn_11:
                Button b11 = (Button) v.findViewById(R.id.btn_11);
                Intent intent11 = new Intent(getApplicationContext(), Philippians.class);
                startActivity(intent11);
                break;
            case R.id.btn_12:
                Button b12 = (Button) v.findViewById(R.id.btn_12);
                Intent intent12 = new Intent(getApplicationContext(), Collosians.class);
                startActivity(intent12);
                break;
            case R.id.btn_13:
                Button b13 = (Button) v.findViewById(R.id.btn_13);
                Intent intent13 = new Intent(getApplicationContext(), First_thessalonian.class);
                startActivity(intent13);
                break;
            case R.id.btn_14:
                Button b14 = (Button) v.findViewById(R.id.btn_14);
                Intent intent14 = new Intent(getApplicationContext(), Second_thessalonian.class);
                startActivity(intent14);
                break;
            case R.id.btn_15:
                Button b15 = (Button) v.findViewById(R.id.btn_15);
                Intent intent15 = new Intent(getApplicationContext(), First_timothy.class);
                startActivity(intent15);
                break;
            case R.id.btn_16:
                Button b16 = (Button) v.findViewById(R.id.btn_16);
                Intent intent16 = new Intent(getApplicationContext(), SecondTimothy.class);
                startActivity(intent16);
                break;
            case R.id.btn_17:
                Button b17 = (Button) v.findViewById(R.id.btn_17);
                Intent intent17 = new Intent(getApplicationContext(), Titus.class);
                startActivity(intent17);
                break;
            case R.id.btn_18:
                Button b18 = (Button) v.findViewById(R.id.btn_18);
                Intent intent18 = new Intent(getApplicationContext(), Philemon.class);
                startActivity(intent18);
                break;
            case R.id.btn_19:
                Button b19 = (Button) v.findViewById(R.id.btn_19);
                Intent intent19 = new Intent(getApplicationContext(), Hebrews.class);
                startActivity(intent19);
                break;
            case R.id.btn_20:
                Button b20 = (Button) v.findViewById(R.id.btn_20);
                Intent intent20 = new Intent(getApplicationContext(), James.class);
                startActivity(intent20);
                break;
            case R.id.btn_21:
                Button b21 = (Button) v.findViewById(R.id.btn_21);
                Intent intent21 = new Intent(getApplicationContext(), First_Peter.class);
                startActivity(intent21);
                break;
            case R.id.btn_22:
                Button b22 = (Button) v.findViewById(R.id.btn_22);
                Intent intent22 = new Intent(getApplicationContext(), Second_Peter.class);
                startActivity(intent22);
                break;
            case R.id.btn_23:
                Button b23 = (Button) v.findViewById(R.id.btn_23);
                Intent intent23 = new Intent(getApplicationContext(), FirstJohn.class);
                startActivity(intent23);
                break;
            case R.id.btn_24:
                Button b24 = (Button) v.findViewById(R.id.btn_24);
                Intent intent24 = new Intent(getApplicationContext(), SecondJohn.class);
                startActivity(intent24);
                break;
            case R.id.btn_25:
                Button b25 = (Button) v.findViewById(R.id.btn_25);
                Intent intent25 = new Intent(getApplicationContext(), ThirdJohn.class);
                startActivity(intent25);
                break;
            case R.id.btn_26:
                Button b26 = (Button) v.findViewById(R.id.btn_26);
                Intent intent26 = new Intent(getApplicationContext(), Jude.class);
                startActivity(intent26);
                break;
            case R.id.btn_27:
                Button b27 = (Button) v.findViewById(R.id.btn_27);
                Intent intent27 = new Intent(getApplicationContext(), Revelation.class);
                startActivity(intent27);
                break;


                //==OLD TESTAMENT==
            case R.id.btn_28:
                Button b28 = (Button) v.findViewById(R.id.btn_28);
                Intent intent28 = new Intent(getApplicationContext(), Genesis.class);
                startActivity(intent28);
                break;
            case R.id.btn_29:
                Button b29 = (Button) v.findViewById(R.id.btn_29);
                Intent intent29 = new Intent(getApplicationContext(), Exodus.class);
                startActivity(intent29);
                break;
            case R.id.btn_30:
                Button b30 = (Button) v.findViewById(R.id.btn_30);
                Intent intent30 = new Intent(getApplicationContext(), Leviticus.class);
                startActivity(intent30);
                break;
            case R.id.btn_31:
                Button b31 = (Button) v.findViewById(R.id.btn_31);
                Intent intent31 = new Intent(getApplicationContext(), Numbers.class);
                startActivity(intent31);
                break;
            case R.id.btn_32:
                Button b32 = (Button) v.findViewById(R.id.btn_32);
                Intent intent32 = new Intent(getApplicationContext(), Deuteronomy.class);
                startActivity(intent32);
                break;
            case R.id.btn_33:
                Button b33 = (Button) v.findViewById(R.id.btn_33);
                Intent intent33 = new Intent(getApplicationContext(), Joshua.class);
                startActivity(intent33);
                break;
            case R.id.btn_34:
                Button b34 = (Button) v.findViewById(R.id.btn_34);
                Intent intent34 = new Intent(getApplicationContext(), Judges.class);
                startActivity(intent34);
                break;
            case R.id.btn_35:
                Button b35 = (Button) v.findViewById(R.id.btn_35);
                Intent intent35 = new Intent(getApplicationContext(), Ruth.class);
                startActivity(intent35);
                break;
            case R.id.btn_36:
                Button b36 = (Button) v.findViewById(R.id.btn_36);
                Intent intent36 = new Intent(getApplicationContext(),First_samuel.class);
                startActivity(intent36);
                break;
            case R.id.btn_37:
                Button b37 = (Button) v.findViewById(R.id.btn_37);
                Intent intent37 = new Intent(getApplicationContext(), Second_samuel.class);
                startActivity(intent37);
                break;
            case R.id.btn_38:
                Button b38 = (Button) v.findViewById(R.id.btn_38);
                Intent intent38 = new Intent(getApplicationContext(), First_king.class);
                startActivity(intent38);
                break;
            case R.id.btn_39:
                Button b39 = (Button) v.findViewById(R.id.btn_39);
                Intent intent39 = new Intent(getApplicationContext(), Second_king.class);
                startActivity(intent39);
                break;
            case R.id.btn_40:
                Button b40 = (Button) v.findViewById(R.id.btn_40);
                Intent intent40 = new Intent(getApplicationContext(), First_chronicle.class);
                startActivity(intent40);
                break;
            case R.id.btn_41:
                Button b41 = (Button) v.findViewById(R.id.btn_41);
                Intent intent41 = new Intent(getApplicationContext(), Second_chronicle.class);
                startActivity(intent41);
                break;
            case R.id.btn_42:
                Button b42 = (Button) v.findViewById(R.id.btn_42);
                Intent intent42 = new Intent(getApplicationContext(), Ezra.class);
                startActivity(intent42);
                break;
            case R.id.btn_43:
                Button b43 = (Button) v.findViewById(R.id.btn_43);
                Intent intent43 = new Intent(getApplicationContext(), Nehemiah.class);
                startActivity(intent43);
                break;
            case R.id.btn_44:
                Button b44 = (Button) v.findViewById(R.id.btn_44);
                Intent intent44 = new Intent(getApplicationContext(), Esther.class);
                startActivity(intent44);
                break;
            case R.id.btn_45:
                Button b45 = (Button) v.findViewById(R.id.btn_45);
                Intent intent45 = new Intent(getApplicationContext(), Job.class);
                startActivity(intent45);
                break;
            case R.id.btn_46:
                Button b46 = (Button) v.findViewById(R.id.btn_46);
                Intent intent46 = new Intent(getApplicationContext(), Psalm.class);
                startActivity(intent46);
                break;
            case R.id.btn_47:
                Button b47 = (Button) v.findViewById(R.id.btn_47);
                Intent intent47 = new Intent(getApplicationContext(), Proverbs.class);
                startActivity(intent47);
                break;
            case R.id.btn_48:
                Button b48 = (Button) v.findViewById(R.id.btn_48);
                Intent intent48 = new Intent(getApplicationContext(), Ecclesiastes.class);
                startActivity(intent48);
                break;
            case R.id.btn_49:
                Button b49 = (Button) v.findViewById(R.id.btn_49);
                Intent intent49 = new Intent(getApplicationContext(), Solomon.class);
                startActivity(intent49);
                break;
            case R.id.btn_50:
                Button b50 = (Button) v.findViewById(R.id.btn_50);
                Intent intent50 = new Intent(getApplicationContext(), Isiah.class);
                startActivity(intent50);
                break;
            case R.id.btn_51:
                Button b51 = (Button) v.findViewById(R.id.btn_51);
                Intent intent51 = new Intent(getApplicationContext(), Jeremiah.class);
                startActivity(intent51);
                break;
            case R.id.btn_52:
                Button b52 = (Button) v.findViewById(R.id.btn_52);
                Intent intent52 = new Intent(getApplicationContext(), Lamentation.class);
                startActivity(intent52);
                break;
            case R.id.btn_53:
                Button b53 = (Button) v.findViewById(R.id.btn_53);
                Intent intent53 = new Intent(getApplicationContext(), Ezekiel.class);
                startActivity(intent53);
                break;
            case R.id.btn_54:
                Button b54 = (Button) v.findViewById(R.id.btn_54);
                Intent intent54 = new Intent(getApplicationContext(), Daniel.class);
                startActivity(intent54);
                break;
            case R.id.btn_55:
                Button b55 = (Button) v.findViewById(R.id.btn_55);
                Intent intent55 = new Intent(getApplicationContext(), Hosiah.class);
                startActivity(intent55);
                break;
            case R.id.btn_56:
                Button b56 = (Button) v.findViewById(R.id.btn_56);
                Intent intent56 = new Intent(getApplicationContext(), Joel.class);
                startActivity(intent56);
                break;
            case R.id.btn_57:
                Button b57 = (Button) v.findViewById(R.id.btn_57);
                Intent intent57 = new Intent(getApplicationContext(), Amos.class);
                startActivity(intent57);
                break;
            case R.id.btn_58:
                Button b58 = (Button) v.findViewById(R.id.btn_58);
                Intent intent58 = new Intent(getApplicationContext(), Obadiah.class);
                startActivity(intent58);
                break;
            case R.id.btn_59:
                Button b59 = (Button) v.findViewById(R.id.btn_59);
                Intent intent59 = new Intent(getApplicationContext(), Jonah.class);
                startActivity(intent59);
                break;
            case R.id.btn_60:
                Button b60 = (Button) v.findViewById(R.id.btn_60);
                Intent intent60 = new Intent(getApplicationContext(), Micah.class);
                startActivity(intent60);
                break;
            case R.id.btn_61:
                Button b61 = (Button) v.findViewById(R.id.btn_61);
                Intent intent61 = new Intent(getApplicationContext(),Nahum.class);
                startActivity(intent61);
                break;
            case R.id.btn_62:
                Button b62 = (Button) v.findViewById(R.id.btn_62);
                Intent intent62 = new Intent(getApplicationContext(), Habbakkuk.class);
                startActivity(intent62);
                break;
            case R.id.btn_63:
                Button b63 = (Button) v.findViewById(R.id.btn_63);
                Intent intent63 = new Intent(getApplicationContext(), Zephaniah.class);
                startActivity(intent63);
                break;
            case R.id.btn_64:
                Button b64 = (Button) v.findViewById(R.id.btn_64);
                Intent intent64 = new Intent(getApplicationContext(), Haggai.class);
                startActivity(intent64);
                break;
            case R.id.btn_65:
                Button b65 = (Button) v.findViewById(R.id.btn_65);
                Intent intent65 = new Intent(getApplicationContext(), Zechariah.class);
                startActivity(intent65);
                break;
            case R.id.btn_66:
                Button b66 = (Button) v.findViewById(R.id.btn_66);
                Intent intent66 = new Intent(getApplicationContext(), Malachi.class);
                startActivity(intent66);
                break;
        }
	}
	
	private void onAboutClick(){
        Uri uri = Uri.parse("www.ifindsolutionorg.blogspot.com/about-me.html");
        Intent intent = new Intent(Intent.ACTION_VIEW,uri);
        startActivity(intent);

    }

    private void RatingFeedBack(){
        Uri uri = Uri.parse( "market://details?id="+getApplicationContext().getPackageName());
        Intent intent = new Intent(Intent.ACTION_VIEW,uri);
        startActivity(intent);
		
    }
    private void onContactClick(){
        Uri uri = Uri.parse("https:www.naldoskie.xyz/p/contact-us.html");
        Intent intent = new Intent(Intent.ACTION_VIEW,uri);
        startActivity(intent);

    }
	
	@Override
    public void showBannerAds() {

    }

    @Override
    public void showInterstitialAds() {
        runOnUiThread(new Runnable() {
				@Override
				public void run() {
					showInsterstialAdInternal();
				}
			});

    }
    private void loadInterstitialAds(){
        if (isNetWorkConnected()){
          interstitialAd.loadAd(AdUtils.adBuilder());
        }
    }

    private void showInsterstialAdInternal(){
       if (interstitialAd.isLoaded()){            
	   interstitialAd.show();
      }
    }


    private void initAds() {


   interstitialAd = new InterstitialAd(this);
   interstitialAd.setAdUnitId(AdUnitID.INTERSTITIAL_ADS);
   interstitialAd.setAdListener(new AdListener(){

            @Override
         public void onAdClosed() {
                loadInterstitialAds();
           }
        });
        loadInterstitialAds();
    }
	 @Override
    public boolean isNetWorkConnected() {
        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        //noinspection deprecation
        NetworkInfo networkInfo = Objects.requireNonNull(connectivityManager).getActiveNetworkInfo();
        //noinspection deprecation
        return  networkInfo != null && networkInfo.isConnected();
    }
	class MyDialogFragment extends DialogFragment
	{
		@RequiresApi(api = Build.VERSION_CODES.M)
        @Override
		public Dialog onCreateDialog(Bundle savedInstanceState) 
		{
			AlertDialog.Builder builder = new AlertDialog.Builder(getContext());

			builder.setTitle("Rate us...");
			builder.setMessage("Do you want to rate this App?");
			builder.setPositiveButton("Ok", new DialogInterface.OnClickListener() {

					@RequiresApi(api = Build.VERSION_CODES.M)
                    @Override
					public void onClick(DialogInterface p1, int p2)
					{
						// TODO: Implement this method
						startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse("market://details?id="+getContext().getPackageName())));

					}
				});

			builder.setNegativeButton("Maybe Later", new DialogInterface.OnClickListener(){

					@Override
					public void onClick(DialogInterface p1, int p2)
					{
						// TODO: Implement this method
					}	
				});

			return builder.create();
		}
	}	
	
}
