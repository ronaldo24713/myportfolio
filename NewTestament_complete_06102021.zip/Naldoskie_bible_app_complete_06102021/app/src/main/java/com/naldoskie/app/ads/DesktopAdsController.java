package com.naldoskie.app.ads;



public class DesktopAdsController implements AdsController {
//    private static final Logger log = new Logger(DesktopAdsController.class.getSimpleName(),Logger.DEBUG);

    @Override
    public void showBannerAds() {

//        log.debug("show banner");
    }

    @Override
    public void showInterstitialAds() {
//        log.debug("show interstitials");

    }

    @Override
    public boolean isNetWorkConnected() {

    return  false;
    }
}
